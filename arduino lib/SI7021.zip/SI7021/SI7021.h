#ifndef SI7021_H
#define SI7021_H

#include <Arduino.h>

class SI7021
{
	public:
	uint8_t temp;
	uint8_t humi;
	bool Si7021_get_temp_humi(uint8_t *data);
	uint32_t SI7021::Si7021_read(uint32_t pin);
	
	private:
	uint32_t SI_PIN;
	uint8_t DHT11ReadValue(void);
};

#endif