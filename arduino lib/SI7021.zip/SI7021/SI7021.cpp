#include "SI7021.h"

uint8_t SI7021::DHT11ReadValue(void)
{
	uint8_t i,uchartemp=0;   
    uint8_t timeout_flag;
    uint8_t ucharcomdata = 0;
    for(i=0;i<8;i++)
	{
         timeout_flag=2; 
         while((digitalRead(SI_PIN) == 0)&&timeout_flag++);
         delayMicroseconds(30); /*30 us 以内为 ‘0 ’*/
         uchartemp=0;
         if(digitalRead(SI_PIN) == 1){
            uchartemp=1;
         }
         timeout_flag=2;
         while((digitalRead(SI_PIN) == 1)&&timeout_flag++);   
         if(timeout_flag==1){
            break;
         }
         ucharcomdata<<=1;
         ucharcomdata|=uchartemp; 
    }    
	
    return ucharcomdata;
}

bool SI7021::Si7021_get_temp_humi(uint8_t *data)
{
	uint8_t i;
    uint8_t timeout_flag;
    uint8_t data_temp = 0;
    uint8_t tem_humi_data[5]={0};
	
    pinMode(SI_PIN,OUTPUT);
	digitalWrite(SI_PIN,LOW);
	delayMicroseconds(500);
	digitalWrite(SI_PIN,HIGH);
	delayMicroseconds(40);
	
	pinMode(SI_PIN,INPUT);
	
	//while(digitalRead(SI_PIN)==1);
	
	if(digitalRead(SI_PIN)==0)
	{
		timeout_flag=2; 
        while((digitalRead(SI_PIN) == 0)&&timeout_flag++); 
        if(timeout_flag == 1)
        {
            //Serial.println("get respond is error");
			return false;
        }
		
		timeout_flag=2;
        while((digitalRead(SI_PIN) == 1)&&timeout_flag++); 
        if(timeout_flag == 1)
        {
            //Serial.println("before send data is error");
            return false;
        }
		
		for(i=0;i<5;i++)
        {
            tem_humi_data[i] = DHT11ReadValue();
            if(i<4)
            {
                data_temp += tem_humi_data[i];
            }
        }
		//Serial.println(tem_humi_data[0]);
		//Serial.println(tem_humi_data[1]);
		//Serial.println(tem_humi_data[2]);
		//Serial.println(tem_humi_data[3]);
		//Serial.println(tem_humi_data[4]);
		//Serial.println(data_temp);
		pinMode(SI_PIN,OUTPUT);
		if(data_temp==tem_humi_data[4] && data_temp != 0)
        {
            digitalWrite(SI_PIN,1); 
            uint16_t temp;
            temp = tem_humi_data[0];
            data[1] = (int8_t)((((temp<<8) | tem_humi_data[1]) & 0x7fff) / 10);
            //Serial.println("temp_humi_data[2] = %d",tem_humi_data[2]);
            if(0 == (tem_humi_data[2] & 0x80))
            {
                temp = tem_humi_data[2];
                data[0] = (int8_t)((((temp<<8) | tem_humi_data[3]) & 0x7fff) / 10);
				//Serial.println("read temp humi OK\r\n");
				return true;
            }
            else
            {
                temp = tem_humi_data[2];
                data[0] = 0 - (int8_t)((((temp<<8) | tem_humi_data[3]) & 0x7fff) / 10);
                //Serial.println("now temp is %d",(int8)((((temp<<8) | tem_humi_data[3]) & 0x7fff) / 10));
                //Serial.println("data[0] is %d",data[0]);
				//Serial.println("read temp humi OK\r\n");
				return true;
            }
        }
        else
        {
            digitalWrite(SI_PIN,1);  
            //Serial.println("rectify error");
            return false;
        }
	}
	
	return false;
}

uint32_t SI7021::Si7021_read(uint32_t pin)
{
	uint32_t ret = 0;
	uint8_t temp_humi_data[2] = {0};
	
	SI_PIN = pin;
	ret = Si7021_get_temp_humi(temp_humi_data);
	if(ret)
	{
		temp = temp_humi_data[0];
		humi = temp_humi_data[1];
	}
	else{
		temp = 0;
		humi = 0;
	}
	//Serial.println(ret);
	return ret;
}